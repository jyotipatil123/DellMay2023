﻿namespace MVC_Dell_net60.Models
{
    public class employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

    }
}
