﻿namespace MVC_Dell_net60.Models
{
    public class Person1
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

    }
}
