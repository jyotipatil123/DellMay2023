﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using MVC_Dell_net60.Models;
using System.Net.Mime;


namespace MVC_Dell_net60.Controllers
{
    public class DellController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //public IActionResult Index()
        //{
        //    ViewBag.msg = "this is a new message";
        //    return View();
        //}

        public ContentResult ContentResultDemo()
        {
            return Content("I am ContentResult-Dell");
        }

        public ViewResult viewresultdemo()
        {
            return View("Index", "Home");
        }

        public ActionResult redirectdemo1()
        {
            return RedirectToAction("Index");
        }

        public RedirectToActionResult Index1()
        {
            return RedirectToAction("Index", "Home");
        }

        //public EmptyResult emptyresultdemo()
        //{
        //    return new EmptyResult();
        //}

        //public JsonResult JsonResultDemo()
        //{
        //    //var name = "Nischal";

        //    //return Json(name);   

        //    var persons = new List<Person1>
        //    {
        //       new Person1{Id=1, FirstName="Harry", LastName="Potter"},
        //       new Person1{Id=2, FirstName="James", LastName="Raj"}
        //    };
        //    return Json(persons);
        //}


        // file return types
        //public FileResult Index3()
        //{
        //    return File(Url.Content("~/demo/filename1.txt"), "text/plain");
        //}

        public PartialViewResult PartialViewResultDemo() 
        {
           return PartialView("DellPartialView");
        }

    }
}
